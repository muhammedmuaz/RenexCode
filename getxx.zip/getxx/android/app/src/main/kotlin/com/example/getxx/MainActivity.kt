package com.example.getxx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
