import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getxx/controllers/usercontroller.dart';
import 'package:getxx/views/UsersPage.dart';

class UserDetail extends StatelessWidget {
  TextEditingController idcontroller = TextEditingController();
  TextEditingController titlecontroller = TextEditingController();
  TextEditingController bodycontroller = TextEditingController();

  @override
  bool shouldPop = true;
  Widget build(BuildContext context) {
    final UserController _usercontroller = Get.find();
    return WillPopScope(
      onWillPop: () async {
        Get.back();
        return shouldPop;
      },
      child: Scaffold(
        body: Container(
            padding: EdgeInsets.all(10.0),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Id",
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 20),
                  ),
                  Text(
                    Get.arguments[1].toString(),
                  ),
                  Text("Title",
                      style:
                          TextStyle(fontWeight: FontWeight.w700, fontSize: 20)),
                  Text(Get.arguments[2]),
                  Text("Body",
                      style:
                          TextStyle(fontWeight: FontWeight.w700, fontSize: 20)),
                  Text(Get.arguments[3]),
                  SizedBox(
                    height: 20,
                  ),
                  Text("Id",
                      style:
                          TextStyle(fontWeight: FontWeight.w700, fontSize: 20)),
                  TextField(
                    controller: idcontroller,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Title",
                      style:
                          TextStyle(fontWeight: FontWeight.w700, fontSize: 20)),
                  TextField(
                    controller: titlecontroller,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text("Body",
                      style:
                          TextStyle(fontWeight: FontWeight.w700, fontSize: 20)),
                  TextField(
                    controller: bodycontroller,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        if (idcontroller.value.toString() != "" ||
                            titlecontroller.value.toString() != "" ||
                            bodycontroller.value.toString() != "") {
                          // Update Value

                          _usercontroller.UpdateUser(
                              Get.arguments[1],
                              int.parse(idcontroller.value.text.toString()),
                              titlecontroller.value.text.toString(),
                              bodycontroller.value.text.toString()
                              );
                          Get.to(MainPage());

                          // for (var i = 0; i < users.length; i++) {
                          //   if (users[i].id == Get.arguments[1]) {
                          //     setState(() {
                          //       users[i].userId =
                          //           int.parse(idcontroller.value.text.toString());
                          //       // titlecontroller
                          //       users[i].title =
                          //           titlecontroller.value.text.toString();
                          //       users[i].body = bodycontroller.value.toString();
                          //     });
                          //   }
                          //   changevalue = true;
                          // }
                          Get.snackbar("Hurray", "Value Updated");
                        }
                      },
                      child: Text("Update details"))
                ])),
      ),
    );
  }
}

bool changevalue = false;
