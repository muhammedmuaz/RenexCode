import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getxx/models/productModel.dart';
import 'package:getxx/views/UserDetail.dart';

import '../controllers/usercontroller.dart';
import '../fetchedData/users.dart';

List<User> users = [];

class MainPage extends StatelessWidget {
  UserController _userconrtoller = Get.put(UserController());

  void adduser() {
    for (var i = 0; i < allusers.length; i++) {
      users.add(User.fromJson(allusers[i]));
    }
  }


  bool shouldPop = true;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return shouldPop;
      },
      child: Scaffold(
        body: Obx(
          (() => _userconrtoller.isdataLoading.value
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                          itemCount: _userconrtoller.users.length,
                          itemBuilder: (BuildContext context, index) {

                            String title = _userconrtoller.users[index].title;
                            int uid = _userconrtoller.users[index].userId;
                            int id = _userconrtoller.users[index].id;
                            String body = _userconrtoller.users[index].body;
                            
                            return ListTile(
                              title: Text(title),
                              trailing: ElevatedButton(
                                  onPressed: () {
                                    Get.to(
                                      UserDetail(),
                                    arguments: [uid,id,body,title]
                                    );
                                  },
                                  child: Text("ShowMore")),
                            );
                          }),
                    )
                  ],
                )),
        ),
      ),
    );
  }
}
