import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getxx/models/productModel.dart';

import '../fetchedData/users.dart';

class UserController extends GetxController {
  List<User> users = [];

  var isdataLoading = false.obs;

  @override
  void onInit() async {
    print("call onInit"); // this line not printing
    // checkIsLogin();
    // print("ww");
    super.onInit();
    FetchUsers();
  }

  FetchUsers() {
    isdataLoading(true);
    Future.delayed(Duration(seconds: 2), () {
      for (var i = 0; i < allusers.length; i++) {
        users.add(User.fromJson(allusers[i]));
      }
      isdataLoading(false);
    });
  }

  UpdateUser(int id, int uid, String title, String body) {
    for (var i = 0; i < users.length; i++) {
      if (users[i].id == id) {
        users[i].userId = uid;
        // titlecontroller
        users[i].title = title;
        users[i].body = body;
      }
    }
  }
}
